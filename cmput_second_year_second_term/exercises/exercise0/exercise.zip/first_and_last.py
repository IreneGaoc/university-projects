'''

title: exercise0: first_and_last
created date: 2016/Jan/09
purpose:
    Write code that reads from the standard input a string of length at least one and prints the first
    and last characters of the string to the standard output.
'''

# input a string
a_String= input()

#print the first and the last character
print(a_String[0],a_String[-1])
